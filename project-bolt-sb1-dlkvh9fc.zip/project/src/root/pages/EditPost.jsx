import React from 'react';

const EditPost = () => {
  return (
    <div className="edit-post-container">
      <h2 className="h3-bold md:h2-bold text-left w-full">Edit Post</h2>
    </div>
  );
};

export default EditPost;