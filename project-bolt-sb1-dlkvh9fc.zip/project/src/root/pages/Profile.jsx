import React from 'react';

const Profile = () => {
  return (
    <div className="profile-container">
      <h2 className="h3-bold md:h2-bold text-left w-full">Profile</h2>
    </div>
  );
};

export default Profile;