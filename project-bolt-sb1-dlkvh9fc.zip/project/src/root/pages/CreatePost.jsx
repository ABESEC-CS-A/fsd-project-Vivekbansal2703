import React from 'react';

const CreatePost = () => {
  return (
    <div className="flex flex-1">
      <div className="create-post-container">
        <h2 className="h3-bold md:h2-bold text-left w-full">Create Post</h2>
      </div>
    </div>
  );
};

export default CreatePost;