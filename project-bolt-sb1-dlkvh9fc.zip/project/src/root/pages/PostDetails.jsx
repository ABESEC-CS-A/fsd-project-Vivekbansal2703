import React from 'react';

const PostDetails = () => {
  return (
    <div className="post-details-container">
      <h2 className="h3-bold md:h2-bold text-left w-full">Post Details</h2>
    </div>
  );
};

export default PostDetails;