import React from 'react';

const UpdateProfile = () => {
  return (
    <div className="update-profile-container">
      <h2 className="h3-bold md:h2-bold text-left w-full">Update Profile</h2>
    </div>
  );
};

export default UpdateProfile;