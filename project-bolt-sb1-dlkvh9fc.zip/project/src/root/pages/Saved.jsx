import React from 'react';

const Saved = () => {
  return (
    <div className="saved-container">
      <h2 className="h3-bold md:h2-bold text-left w-full">Saved Posts</h2>
    </div>
  );
};

export default Saved;