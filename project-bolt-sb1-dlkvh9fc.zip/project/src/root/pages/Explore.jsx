import React from 'react';

const Explore = () => {
  return (
    <div className="explore-container">
      <h2 className="h3-bold md:h2-bold text-left w-full">Explore</h2>
    </div>
  );
};

export default Explore;