import React from 'react';

const AllUsers = () => {
  return (
    <div className="all-users-container">
      <h2 className="h3-bold md:h2-bold text-left w-full">All Users</h2>
    </div>
  );
};

export default AllUsers;