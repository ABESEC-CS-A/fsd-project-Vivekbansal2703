import React from 'react';
import { Outlet, Navigate } from 'react-router-dom';

const RootLayout = () => {
  const isAuthenticated = false;

  return (
    <>
      {!isAuthenticated ? (
        <Navigate to="/sign-in" />
      ) : (
        <div className="w-full md:flex">
          <section className="flex flex-1 h-full">
            <Outlet />
          </section>
        </div>
      )}
    </>
  );
};

export default RootLayout;