import React from 'react';
import { Link } from 'react-router-dom';

const SignupForm = () => {
  return (
    <div className="sm:w-420 flex-center flex-col">
      <h2 className="h3-bold md:h2-bold pt-5 sm:pt-12">
        Create a new account
      </h2>
      <p className="text-light-3 small-medium md:base-regular mt-2">
        To use our platform, please enter your details
      </p>

      <form className="flex flex-col gap-5 w-full mt-4">
        <div>
          <label className="text-light-2">Name</label>
          <input 
            type="text" 
            className="w-full bg-dark-3 text-light-1 p-3 rounded-lg mt-1"
            placeholder="Enter your name"
          />
        </div>

        <div>
          <label className="text-light-2">Username</label>
          <input 
            type="text" 
            className="w-full bg-dark-3 text-light-1 p-3 rounded-lg mt-1"
            placeholder="Enter your username"
          />
        </div>
        
        <div>
          <label className="text-light-2">Email</label>
          <input 
            type="email" 
            className="w-full bg-dark-3 text-light-1 p-3 rounded-lg mt-1"
            placeholder="Enter your email"
          />
        </div>
        
        <div>
          <label className="text-light-2">Password</label>
          <input 
            type="password" 
            className="w-full bg-dark-3 text-light-1 p-3 rounded-lg mt-1"
            placeholder="Enter your password"
          />
        </div>

        <button 
          type="submit"
          className="bg-primary-500 text-light-1 p-3 rounded-lg hover:bg-primary-600 transition-colors"
        >
          Sign Up
        </button>
      </form>

      <p className="text-light-2 text-small-regular mt-4">
        Already have an account?{" "}
        <Link to="/sign-in" className="text-primary-500 text-small-semibold ml-1">
          Sign in
        </Link>
      </p>
    </div>
  );
};

export default SignupForm;